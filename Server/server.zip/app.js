import "dotenv/config";
import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import connectDB from "./config/database.js";
import eventRouter from "./routes/event.routes.js";
import ticketRouter from "./routes/ticket.routes.js";
import commentRouter from "./routes/comment.routes.js";
import wishlistRouter from "./routes/wishlist.routes.js";
import notiRouter from "./routes/notification.routes.js";
import authRouter from "./routes/auth.routes.js";
import adminSettingsRouter from "./routes/adminSettings.routes.js";
import userProfilesRouter from "./routes/profile.routes.js";
import adminRouter from "./routes/admin.routes.js";
import cookieParser from "cookie-parser";
import passport from "./config/googleAuth.js";
import session from "express-session";
import rateLimit from "express-rate-limit";
import errorHandler from "./errors/errorHandler.js";
import { expirePendingTickets } from "./utils/ticketExpiry.js";
import {
  Event,
  Concert,
  Festival,
  GenericEvent,
} from "./models/events.model.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5002;

//connect the db
const startServer = async () => {
  try {
    await connectDB();
    // Run once on startup, then every 10 minutes

    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error("Server failed to start:", error);
  }
};
const limiter = rateLimit({
  windowMs: 150 * 60 * 1000, // 15 minutes
  max: 100, // max 100 requests per IP
  message: {
    success: false,
    message: "Too many requests, please try again later.",
  },
  standardHeaders: true,
  legacyHeaders: false,
});

app.use(express.json());
app.use(
  cors({
    origin: function (origin, callback) {
      const allowedOrigins = [
        "http://localhost:5173",
        "https://paysso.netlify.app",
        "https://paysso.et",
      ];

      // Allow requests with no origin (like mobile apps or curl requests)
      // Also allow any local network IPs for mobile testing (e.g., http://192.168...)
      if (
        !origin ||
        allowedOrigins.includes(origin) ||
        origin.startsWith("http://192.168.") ||
        origin.startsWith("http://10.")
      ) {
        callback(null, true);
      } else {
        callback(new Error("Not allowed by CORS"));
      }
    },
    credentials: true,
  }),
);
app.use(cookieParser());
app.use("/assets", express.static(path.join(process.cwd(), "assets")));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));
app.set("trust proxy", 1);

app.use(passport.initialize());

app.use("/api/auth", authRouter);

app.use("/api", eventRouter);
app.use("/api", commentRouter);

app.use("/api/auth", userProfilesRouter);
app.use("/api/auth", ticketRouter);
app.use("/api/auth", wishlistRouter);
app.use("/api/auth", notiRouter);
app.use("/api/auth/admin", adminRouter);
app.use("/api/auth/admin", adminSettingsRouter);
app.use(errorHandler);
startServer();
